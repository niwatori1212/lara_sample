// // Retrieve Job-defined env vars
// const { CLOUD_RUN_TASK_INDEX = 0, CLOUD_RUN_TASK_ATTEMPT = 0 } = process.env;
// // Retrieve User-defined env vars
// const { SLEEP_MS, FAIL_RATE } = process.env;

// import * as dotenv from "dotenv";

// // Define main script
// const main = async (): Promise<void> => {
//   dotenv.config();

//   console.log(
//     `Starting Task #${process.env.CLOUD_RUN_TASK_INDEX}, Attempt #${process.env.CLOUD_RUN_TASK_ATTEMPT}...`
//   );
//   // Simulate work
//   if (process.env.SLEEP_MS) {
//     await sleep(Number(process.env.SLEEP_MS));
//   }
//   // Simulate errors
//   if (process.env.FAIL_RATE) {
//     try {
//       randomFailure(Number(process.env.FAIL_RATE));
//     } catch (err) {
//       if (err instanceof Error) {
//         err.message = `Task #${process.env.CLOUD_RUN_TASK_INDEX}, Attempt #${process.env.CLOUD_RUN_TASK_ATTEMPT} failed.\n\n${err.message}`;
//         throw err;
//       } else {
//         console.log("unexpected error");
//         throw err;
//       }
//     }
//   }
//   console.log(`Completed Task #${process.env.CLOUD_RUN_TASK_INDEX}.`);
// };

// // Wait for a specific amount of time
// const sleep = (ms: number): Promise<void> => {
//   return new Promise((resolve) => setTimeout(resolve, ms));
// };

// // Throw an error based on fail rate
// const randomFailure = (rate: number): void => {
//   rate = parseFloat(rate.toString());
//   if (!rate || rate < 0 || rate > 1) {
//     console.warn(
//       `Invalid FAIL_RATE env var value: ${rate}. Must be a float between 0 and 1 inclusive.`
//     );
//     return;
//   }

//   const randomFailure = Math.random();

//   console.log("設定数");
//   console.log(randomFailure);
//   console.log(rate);

//   if (randomFailure < rate) {
//     throw new Error("Task failed.");
//   }
// };

// // Start script
// main().catch((err) => {
//   console.error(err);
//   process.exit(1); // Retry Job Task by exiting the process
// });

//
//
//
// 別アプリケーション
//
//
//

// BigQueryをローカル上でテストした

import { BigQuery, JobLoadMetadata } from "@google-cloud/bigquery";
import * as dotenv from "dotenv";

const main = async () => {
  dotenv.config();
  const bigQueryClient = new BigQuery();
  const metadata: JobLoadMetadata = {
    sourceFormat: "NEWLINE_DELIMITED_JSON",
    autodetect: true, // スキーマ定義を autodetect する
    location: "asia-northeast1",
  };
  const datasetId = "cloud_run_job_test"; // 作成したデータセット名を指定
  const tableId = "sample_table"; // 作成されるテーブル名を指定 (命名は任意)
  const [job] = await bigQueryClient
    .dataset(datasetId)
    .table(tableId)
    .load("./sample-data.jsonl", metadata); // 読み込む対象のファイル場所を指定
  console.log(`Job ${job.id} completed.`);
};

main();
