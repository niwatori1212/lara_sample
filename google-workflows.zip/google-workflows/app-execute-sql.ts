import { DataTransferServiceClient } from "@google-cloud/bigquery-data-transfer";
const client = new DataTransferServiceClient();

async function startScheduledQuery(): Promise<void> {
  const transferConfigName: string = `projects/316234347172/locations/asia-northeast1/transferConfigs/65f4f7ac-0000-230d-8d67-c82add781558`;

  const requestedRunTime = new Date(); // この例では現在時刻を使用していますが、特定の時刻を指定することも可能です。

  try {
    const [response] = await client.startManualTransferRuns({
      parent: transferConfigName,
      // ここでは追加のオプションを指定できます。例えば、特定の日付で実行をスケジュールすることも可能です。
      requestedRunTime: {
        seconds: Math.floor(requestedRunTime.getTime() / 1000),
      },
    });
    console.log("Started manual transfer run:", response);
  } catch (error) {
    console.error("Failed to start manual transfer run:", error);
  }
}

// 例の実行
startScheduledQuery();
