// サンプルソースをtypescript化したもの
import {
  DataTransferServiceClient,
  protos,
} from "@google-cloud/bigquery-data-transfer";
const client = new DataTransferServiceClient();

async function quickstart(): Promise<void> {
  const projectId: string = await client.getProjectId();

  // Iterate over all elements.
  const formattedParent: string = client.projectPath(projectId);
  let nextRequest: protos.google.cloud.bigquery.datatransfer.v1.IListDataSourcesRequest | null =
    { parent: formattedParent };
  const options = { autoPaginate: false };

  console.log("Data sources:");
  do {
    if (!nextRequest) break; // If nextRequest is null, exit the loop

    // Fetch the next page.
    const responses = await client.listDataSources(nextRequest, options);
    // The actual resources in a response.
    const resources = responses[0];
    // The next request if the response shows that there are more responses.
    nextRequest =
      responses[1] as protos.google.cloud.bigquery.datatransfer.v1.IListDataSourcesRequest | null;
    resources.forEach((resource) => {
      console.log(`  ${resource.name}`);
    });
  } while (nextRequest);

  console.log("\n\n");
  console.log("Sources via stream:");

  client
    .listDataSourcesStream({ parent: formattedParent })
    .on("data", (element) => {
      console.log(`  ${element.name}`);
    });
}

quickstart();
