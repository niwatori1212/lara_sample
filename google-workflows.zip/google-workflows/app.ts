import { DataTransferServiceClient } from "@google-cloud/bigquery-data-transfer";
const client = new DataTransferServiceClient();

async function checkStatusScheduledQuery(): Promise<void> {
  const runName: string = `projects/316234347172/locations/asia-northeast1/transferConfigs/65f4f7ac-0000-230d-8d67-c82add781558/runs/65f5babe-0000-2a5d-a842-3c286d3ae646`;

  try {
    const [transferRun] = await client.getTransferRun({ name: runName });
    // ステータスをコンソールに出力
    console.log(`Transfer Run Status: ${transferRun.state}`);
    // ステータスに応じた追加情報を表示することも可能です
    if (transferRun.errorStatus && transferRun.errorStatus.message) {
      console.log(`Error Message: ${transferRun.errorStatus.message}`);
    }
  } catch (error) {
    console.error("Failed to check the transfer run status:", error);
  }
}

// 例の実行
checkStatusScheduledQuery();

// datatransferのドキュメント
// https://cloud.google.com/bigquery-transfer/docs/reference/datatransfer/rpc/google.cloud.bigquery.datatransfer.v1?hl=ja#google.cloud.bigquery.datatransfer.v1.TransferRun

// https://blog.g-gen.co.jp/entry/difference-of-gloud-auth-commands
// gcloud auth loginとgcloud auth application-default loginの違いとは？
// /Users/paasmallfactory/.config/iCloud
// application_default_credentials.json
// credentials.db

// 後で読む
// https://qiita.com/miazak/items/8331b1043b8693e6442b

// Workflows で Connector を使って Cloud Run を実行する
// https://qiita.com/c-irei/items/19aaa8d79f2f71265a78
