import { google } from 'googleapis';
import { Request, Response } from 'express';

exports.checkStatus = async (req: Request, res: Response) => {
  const runName: string = req.body.run_name;

  // Google Cloud認証を初期化
  const auth = new google.auth.GoogleAuth({
    scopes: ['https://www.googleapis.com/auth/cloud-platform'],
  });
  const authClient = await auth.getClient();

  // BigQuery Data Transfer Serviceのクライアントを初期化
  const bigquerydatatransfer = google.bigquerydatatransfer({
    version: 'v1',
    auth: authClient,
  });

  try {
    // ジョブのステータスを取得
    const response = await bigquerydatatransfer.projects.locations.transferConfigs.runs.get({
      name: runName,
    });
    res.status(200).send({ status: response.data.state });
  } catch (error) {
    console.error('Failed to check job status:', error);
    res.status(500).send(error);
  }
};