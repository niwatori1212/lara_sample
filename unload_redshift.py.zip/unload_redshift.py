import json
import time
import boto3
from datetime import datetime, timedelta

# Redshift接続情報
CLUSTER_NAME='redshift-cluster-1-jun'
DATABASE_NAME='dev'
DB_USER='awsuser'

# JSTで現在の日付を取得（UTCから9時間加算）
jst_time = datetime.utcnow() + timedelta(hours=9)
date_str = jst_time.strftime('%Y%m%d')  # YYYYMMDD形式

sql = f'''
    UNLOAD ('SELECT * FROM dev.public.category where catid >= 6 order by catid') TO 's3://unload-red-test/{date_str}/' iam_role 'arn:aws:iam::450238422499:role/service-role/AmazonRedshift-CommandsAccessRole-20230908T174611' delimiter ',' allowoverwrite;
'''

def lambda_handler(event, context):

    # Redshiftにクエリを投げる。非同期なのですぐ返ってくる
    data_client = boto3.client('redshift-data')
    result = data_client.execute_statement(
        ClusterIdentifier=CLUSTER_NAME,
        Database=DATABASE_NAME,
        DbUser=DB_USER,
        Sql=sql,
    )

    # 実行IDを取得
    id = result['Id']

    # クエリが終わるのを待つ
    statement = ''
    status = ''
    while status != 'FINISHED' and status != 'FAILED' and status != 'ABORTED':
        statement = data_client.describe_statement(Id=id)
        status = statement['Status']
        time.sleep(1)

    # 結果の表示
    if status == 'FINISHED':
        if int(statement['ResultSize']) > 0:
            # select文等なら戻り値を表示
            statement = data_client.get_statement_result(Id=id)
            print(json.dumps(statement['Records']))
        else:
            # 戻り値がないものはFINISHだけ出力して終わり
            print('QUERY FINISHED')
    elif status == 'FAILED':
        # 失敗時、エラーメッセージを含む例外を投げる
        error_message = f"QUERY FAILED: {statement['Error']}"
        raise Exception(error_message)
    elif status == 'ABORTED':
        # ユーザによる停止時
        print('QUERY ABORTED: The query run was stopped by the user.')
